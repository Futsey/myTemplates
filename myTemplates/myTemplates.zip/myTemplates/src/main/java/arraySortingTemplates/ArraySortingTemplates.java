package arraySortingTemplates;

public class ArraySortingTemplates {

    /*
     * Сортировка по возрастанию true
     */
    public static boolean isSorted(int[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            if (array[i] > array[i + 1]) {
                String res = "Массив нихера не в порядке возрастания";
                System.out.println(res);
                return false;
            }
        }
        String rsl = "Массив отсортирован в порядке возрастания";
        System.out.println(rsl);
        return true;
    }

    /*
     * Поиск одинаковых элементов
     * TODO результат в консоль выводится дважды. (UPD Исправлено оператором "break")
     */
    public static void printCrossEl(int[] left, int[] right) {
        for (int i = 0; i < left.length; i++) {
            int rslI = left[i];
            for (int k = 0; k < right.length; k++) {
                int rslK = right[k];
                if (rslI == rslK) {
                    int result = rslK;
                    System.out.println("Найдены одинаковые элементы со значением: " + result);
                    break;
                }
            }
        }
    }

    /*
     * Даны два отсортированных по возрастанию массива. Как без сортировки их объединить в третий массив?
     * Сортировка слиянием (без сортировки по условиям задачи =))
     */
    public static int[] merge(int[] left, int[] right) {
        int[] array = new int[left.length + right.length];
        int positionA1 = 0;
        int positionA2 = 0;

        for(int i = 0; i < array.length; i++) {
            if(positionA1 == left.length){
                array[i] = right[positionA2];
                System.out.println("Добавлен новый элемент: " + array[i]);
                positionA2++;
            } else if(positionA2 == right.length){
                array[i] = left[positionA1];
                System.out.println("Добавлен новый элемент: " + array[i]);
                positionA1++;
            } else if(left[positionA1] < right[positionA2]){
                array[i] = left[positionA1];
                System.out.println("Добавлен новый элемент: " + array[i]);
                positionA1++;
            } else {
                array[i] = right[positionA2];
                System.out.println("Добавлен новый элемент: " + array[i]);
                positionA2++;
            }
        }
        return array;
    }

    public static void main(String[] args) {
        // Пример для сортировки по возрастанию
        int[] array = new int[]{1, 2, 3, 4, 5, 6, 7};
        ArraySortingTemplates main = new ArraySortingTemplates();
        main.isSorted(array);

        //Пример для поиска одинаковых элементов
        int[] left = new int[]{1, 3, 3, 4, 5, 6, 7};
        int[] right = new int[]{2, 4, 10, 11, 12, 4, 3};
        ArraySortingTemplates equalElements = new ArraySortingTemplates();
        equalElements.printCrossEl(left, right);

        //Объединяем два отсортированных массивов в третий без сортировки
        int[] leftSide = new int[]{1, 3};
        int[] rightSide = new int[]{2, 4};
        ArraySortingTemplates mergedArray = new ArraySortingTemplates();
        mergedArray.merge(leftSide, rightSide);
    }
}


